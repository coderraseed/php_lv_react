<?php 
//! echo function 
    echo " I am a trainee of SoftTechIt\n";
    echo "My teacher name is MTM Sujon\n";

    //Variable 

    $name = "Rasedul Islam";
    $age = 21;

    echo "My name is {$name}, age {$age}\n";

    //!Data type

    //? Integer
    echo 78;
    //string
    echo "This is a string type data\n";
    //?float/Double
    echo "This is a floating Number=2.345 \n";
    //Boolean
    $n=4;
    if($n%2==0){
        echo true;
    }else{
        echo false;
    }
    echo PHP_EOL;
    //?Null
    $dosomthing = Null;
    echo $dosomthing;
    echo PHP_EOL;

    //!array
    $x=[1,3,5,6];
    echo $x[2];
    echo PHP_EOL;

    print "Ami valo asi\n";

    //concat

    $a= "amar";
    $b="nam";
    echo $a." ". $b;

    //phpinfo(); To show all info about php

    
